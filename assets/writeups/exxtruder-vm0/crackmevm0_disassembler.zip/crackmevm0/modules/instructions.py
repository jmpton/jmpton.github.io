class Insn:
    def __init__(self, pc: int, bytecode: bytearray, insn_info: dict):
        """
        bytemask 0xFF is applied to operand1 and operand2 to ensure having
        unsigned value. 
        This is because Java bytes returned by getByte() are signed;
        see https://github.com/NationalSecurityAgency/ghidra/issues/1969
        """
        self.pc = pc
        self.insn_info = insn_info

        self.len = self.get_len()
        self.opcode = self.get_opcode()
        self.mnemonic = self.get_mnemonic().decode("utf8")
        self.operand_count = self.get_operand_count()

        self.operand1_type = None
        self.operand2_type = None
        self.raw_operand1 = None 
        self.raw_operand2 = None 
        self.resolved_operand1 = None 
        self.resolved_operand2 = None 

    def __repr__(self):
        return "Not repr available yet"

    def get_len(self):
        return (1 + self.insn_info["operand_count"])
    def get_opcode(self):
        return self.insn_info["opcode"]
    def get_mnemonic(self):
        return self.insn_info["mnemonic"]
    def get_operand_count(self):
        return self.insn_info["operand_count"]
    def get_operand1_type(self):
        pass
    def get_operand2_type(self):
        pass
    def get_raw_operand1(self):
        pass
    def get_raw_operand2(self):
        pass
    def get_resolved_operand1(self):
        pass
    def get_resolved_operand2(self):
        pass

    def resolve_read_operand(self, bytecode, operand, operand_type) -> str:
        """ function read_operand() """
        if operand_type == 0:
            string = hex(operand)
        elif operand_type == 1:
            string = f"[{hex(operand)}]"
        elif operand_type == 2:
            offset = bytecode[operand]
            string = f"[@{hex(operand)}] -> {hex(bytecode[offset])}"
        else:
            raise RuntimeError(f"Invalid operand type {operand_type}")
        return string

    def resolve_write_operand(self, bytecode, operand, operand_type) -> str:
        """ function write_operand() """
        if operand_type == 2:
            offset = bytecode[operand]
            string = f"[@{hex(offset)}]"
        else:
            string = f"[{hex(operand)}]"
        return string

class InsnMov(Insn):
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
        self.operand1_type = self.get_operand1_type()
        self.operand2_type = self.get_operand2_type()
        self.raw_operand1 = self.get_raw_operand1(bytecode) & 0xff
        self.raw_operand2 = self.get_raw_operand2(bytecode) & 0xff

        self.resolved_operand1 = self.resolve_write_operand(bytecode, self.raw_operand1, self.operand1_type)
        self.resolved_operand2 = self.resolve_read_operand(bytecode, self.raw_operand2, self.operand2_type)

    def get_operand1_type(self):
        return self.insn_info["operand1_type"]
    def get_operand2_type(self):
        return self.insn_info["operand2_type"]
    def get_raw_operand1(self, bytecode):
        return bytecode[self.pc+1]
    def get_raw_operand2(self, bytecode):
        return bytecode[self.pc+2]
    def __repr__(self):
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} {self.raw_operand1:02x} {self.raw_operand2:02x} | "
        r += f"{self.mnemonic} {self.resolved_operand1}, {self.resolved_operand2}"
        return r

class InsnOut(Insn):
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
    def __repr__(self):
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} "
        r += " "*5
        r += " | "
        r += f"{self.mnemonic} bytecode[0xfc:0cfc+[0xfd]]" # 0xfc and 0xfd hardcoded in VM
        return r

class InsnIn(Insn):
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
    def __repr__(self):
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} "
        r += " "*5
        r += " | "
        r += f"{self.mnemonic}  bytecode[0xfc:0xfc+[0xfd]]" # 0xfc and 0xfd hardcoded in VM
        return r

class InsnEnd(Insn):
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
    def __repr__(self):
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} "
        r += " "*5
        r += " | "
        r += f"{self.mnemonic}"
        return r

class InsnCmp(Insn):
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
        self.operand1_type = self.get_operand1_type()
        self.operand2_type = self.get_operand2_type()
        self.raw_operand1 = self.get_raw_operand1(bytecode) & 0xff
        self.raw_operand2 = self.get_raw_operand2(bytecode) & 0xff
        self.resolved_operand1 = self.resolve_read_operand(bytecode, self.raw_operand1, self.operand1_type)
        self.resolved_operand2 = self.resolve_read_operand(bytecode, self.raw_operand2, self.operand2_type)
    def get_operand1_type(self):
        return self.insn_info["operand1_type"]
    def get_operand2_type(self):
        return self.insn_info["operand2_type"]
    def get_raw_operand1(self, bytecode):
        return bytecode[self.pc+1]
    def get_raw_operand2(self, bytecode):
        return bytecode[self.pc+2]
    def __repr__(self):
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} {self.raw_operand1:02x} {self.raw_operand2:02x} | "
        r += f"{self.mnemonic} {self.resolved_operand1}, {self.resolved_operand2}"
        return r

class InsnUnary(Insn):
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
        self.operand1_type = self.get_operand1_type()
        self.raw_operand1 = self.get_raw_operand1(bytecode) & 0xff

        self.resolved_operand1 = self.resolve_read_operand(bytecode, self.raw_operand1, self.operand1_type)
    def get_operand1_type(self):
        return self.insn_info["operand1_type"]
    def get_raw_operand1(self, bytecode):
        return bytecode[self.pc+1]
    def __repr__(self):
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} {self.raw_operand1:02x}    | "
        r += f"{self.mnemonic} {self.resolved_operand1}"
        return r

class InsnJcc(Insn):
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
        self.operand1_type = self.get_operand1_type()
        self.raw_operand1 = self.get_raw_operand1(bytecode) & 0xff
        self.resolved_operand1 = self.resolve_read_operand(bytecode, self.raw_operand1, 0)
    def get_operand1_type(self):
        return self.insn_info["operand1_type"]
    def get_raw_operand1(self, bytecode):
        return bytecode[self.pc+1]
    def __repr__(self):
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} {self.raw_operand1:02x}    | "
        r += f"{self.mnemonic} {self.resolved_operand1}"
        return r

class InsnBitwise(Insn):
    """ TODO: veflags """
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
        self.operand1_type = self.get_operand1_type()
        self.operand2_type = self.get_operand2_type()
        self.raw_operand1 = self.get_raw_operand1(bytecode) & 0xff
        self.raw_operand2 = self.get_raw_operand2(bytecode) & 0xff
        self.resolved_operand1 = self.resolve_read_operand(bytecode, self.raw_operand1, self.operand1_type)
        self.resolved_operand2 = self.resolve_read_operand(bytecode, self.raw_operand2, self.operand2_type)
    def get_operand1_type(self):
        return self.insn_info["operand1_type"]
    def get_operand2_type(self):
        return self.insn_info["operand2_type"]
    def get_raw_operand1(self, bytecode):
        return bytecode[self.pc+1]
    def get_raw_operand2(self, bytecode):
        return bytecode[self.pc+2]
    def __repr__(self):
        # add op1, op2; todo: veflags
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} {self.raw_operand1:02x} {self.raw_operand2:02x} | " 
        r += f"{self.mnemonic} {self.resolved_operand1}, {self.resolved_operand2}"
        r += " ; TODO: virtual eflags"
        return r

class InsnAdd(Insn):
    """
    *veflags = result_lowb == 0;
    veflags[1] = result_lowb >> 7;
    veflags[2] = above_or_carry;
    veflags[3] = signed;
    """
    def __init__(self, pc, bytecode, insn_info):
        super().__init__(pc, bytecode, insn_info)
        self.operand1_type = self.get_operand1_type()
        self.operand2_type = self.get_operand2_type()
        self.raw_operand1 = self.get_raw_operand1(bytecode) & 0xff
        self.raw_operand2 = self.get_raw_operand2(bytecode) & 0xff
        self.resolved_operand1 = self.resolve_read_operand(bytecode, self.raw_operand1, self.operand1_type)
        self.resolved_operand2 = self.resolve_read_operand(bytecode, self.raw_operand2, self.operand2_type)
    def get_operand1_type(self):
        return self.insn_info["operand1_type"]
    def get_operand2_type(self):
        return self.insn_info["operand2_type"]
    def get_raw_operand1(self, bytecode):
        return bytecode[self.pc+1]
    def get_raw_operand2(self, bytecode):
        return bytecode[self.pc+2]
    def __repr__(self):
        # add op1, op2; todo: veflags
        r = f"0x{self.pc:02x}: "
        r += f"{self.opcode:02x} {self.raw_operand1:02x} {self.raw_operand2:02x} | " 
        r += f"{self.mnemonic} {self.resolved_operand1}, {self.resolved_operand2}"
        r += " ; TODO: virtual eflags"
        return r

