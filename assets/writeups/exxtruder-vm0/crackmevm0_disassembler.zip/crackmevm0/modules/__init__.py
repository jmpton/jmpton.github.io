print("ccc")
