# in order to take changes in the code during developpement, I had to
# uncomment VMARGS=-Dpyghidra.sys.modules.restore=true in $GHIDRA_HOME/support/launch.properties
# See https://github.com/NationalSecurityAgency/ghidra/issues/8529
# 
import struct
from .instructions import *
# 
mov_opcodes = {0x00, 0x01, 0x2f, 0x30, 0x31, 0x32}
cmp_opcodes = {0x18, 0x19, 0x54, 0x55, 0x56}  
# i/o
out_opcodes = {0x2d}
in_opcodes = {0x2e}
end_opcodes = {0x2c}
# branch #branch_opcodes = {0x1b, 0x1d, 0x1f, 0x21, 0x23, 0x25, 0x27}
jne_opcodes = {0x1e}
jb_opcodes={0x24}
ja_opcodes={0x20}
# bitwise
and_opcodes = {0x09, 0x0a, 0x3f, 0x40, 0x41}
xor_opcodes = {0x0c, 0x0d, 0x42, 0x43, 0x44}
or_opcodes = {0x07, 0x08, 0x3c, 0x3d, 0x3e}
rol_opcodes = {0x0e, 0x0f, 0x45, 0x46, 0x47}
ror_opcodes = {0x10, 0x11, 0x48, 0x49, 0x4a}
lshift_opcodes = {0x12, 0x13, 0x4b, 0x4c, 0x4d}
# arithmetic
add_opcodes = { 0x03, 0x04, 0x36, 0x37}
#sub_opcodes= {0x05, 0x06, 0x38, 0x39, 0x3a, 0x3b}
# unary 
not_opcodes = {0x0b, 0x53}
inc_opcodes = {0x16, 0x51}
dec_opcodes = {0x17, 0x52}


class Disasm:

    def __init__(self, work_buffer: bytearray, insn_info: dict):
        #self.bytecode = bytecode
        self.insn_info = insn_info
        self.work_buffer = work_buffer
        
        self.pc = 0
        self.disasm()

    def disasm(self):
        print(self.work_buffer)

        todo = {0}
        done = set()
        while todo:
            queued_pc = todo.pop()
            if queued_pc not in done:
                #done.add(queued_pc)
                self.pc = queued_pc
            else:
                continue
            while self.pc < 0x72: # virtual data start
            #while pc < len(self.bytecode):
                opc = self.work_buffer[self.pc]
                if opc > 0x56:
                    invalid_opc = hex(opc&0xff)
                    raise RuntimeError(f"Encountered invalid opcode: {invalid_opc} @{hex(self.pc)}")
                try:
                    insn_info = self.insn_info[opc]
                except KeyError:
                    print(f"[!] Encountered invalid opcode '{hex(opc)}'; pc={hex(self.pc)}")
                    break
               
                insn = self.decode_insn(insn_info)
                print(insn)

                if insn.__class__.__name__ == "InsnJcc":
                    dest_branch = int(insn.resolved_operand1, 16)
                    todo.add(dest_branch)
                if insn is None:
                    break
                done.add(self.pc)
                self.pc += insn.len
            
    def decode_insn(self, insn_info):
        opc = insn_info["opcode"]
        if opc in mov_opcodes:
            return InsnMov(self.pc, self.work_buffer, insn_info)
        elif opc in out_opcodes:
            return InsnOut(self.pc, self.work_buffer, insn_info)
        elif opc in in_opcodes:
            return InsnIn(self.pc, self.work_buffer, insn_info)
        elif opc in cmp_opcodes:
            return InsnCmp(self.pc, self.work_buffer, insn_info)
        elif opc in jne_opcodes or opc in ja_opcodes or opc in jb_opcodes:
            return InsnJcc(self.pc, self.work_buffer, insn_info)
        elif opc in and_opcodes or opc in or_opcodes or opc in xor_opcodes:
            return InsnBitwise(self.pc, self.work_buffer, insn_info)
        elif opc in not_opcodes or opc in inc_opcodes or opc in dec_opcodes:
            return InsnUnary(self.pc, self.work_buffer, insn_info)
        elif opc in add_opcodes:
            return InsnAdd(self.pc, self.work_buffer, insn_info)
        elif opc in end_opcodes:
            return InsnEnd(self.pc, self.work_buffer, insn_info)

        else:
            print("TODO:", hex(self.pc), insn_info)
 
        return None


