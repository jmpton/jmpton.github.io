# Solution to crackmevm0
# https://crackmes.one/crackme/692ca13c2d267f28f69b8224
#@author silma
#@category crackmes
#@keybinding 
#@menupath 
#@toolbar 

import jpype
import struct
import sys

from ghidra.util.task import ConsoleTaskMonitor
from ghidra.program.model.address import Address

from modules.disasm import Disasm

BYTECODE_ADDR = 0x140004000
BYTECODE_LEN = 0xC8  # 0x1400040c8


INSN_INFO_ADDR = 0x140005080
INSN_INFO_ENTRY_COUNT = 88
INSN_INFO_ENTRY_SIZE = 0x20
INSN_INFO_LEN = INSN_INFO_ENTRY_COUNT * INSN_INFO_ENTRY_SIZE

def make_address(a: int) -> Address:
    return address_factory.getDefaultAddressSpace().getAddress(a)

def read_data_at(a: int, l: int) -> bytes:
    """
    Create an 'Address' object from 'a'
    Create a 'JByte' object of length 'l'
    Get the 'MemoryBlock' object containing the data
    Read the data
    """
    addr = make_address(a)
    byte_array = jpype.JByte[l]
    memblock = currentProgram.memory.getBlock(addr)
    count = memblock.getBytes(addr, byte_array)    
    assert(count == l)
    return bytes(byte_array)

def read_string_at(a: Address) -> str:
    """ 
    because s = getDataAt(mnem_addr) works only if the
    string has already been typed as such in the GUI
    """
    s = b''
    memblock = currentProgram.memory.getBlock(a)

    while True:
        if monitor.isCancelled():
            break

        b = struct.pack("b", memblock.getByte(a))
        if b == b'\x00':
            break
        s += b
        a = a.next()
    return s

def dump_insn_info(blob: bytes) -> dict:
    """
    Dump instruction info and format it like below:
        { virtual_opcode: {
            mnem: str, 
            operand_count: int, 
            operand1_type: int, 
            operand2_type: int
            },
            ...
        }
    This way, insn info of a given virtual opcode 
    can easily be acessed using insn_info[opcode]
    """
    i = 0
    all_insn_info_2 = {}
    while i < INSN_INFO_ENTRY_COUNT:
        if monitor.isCancelled():
            break
    
        raw = blob[i*INSN_INFO_ENTRY_SIZE:i*INSN_INFO_ENTRY_SIZE+0x20]
        field_0 = struct.unpack("<I", raw[0:4])[0]
        mnem_addr = make_address(struct.unpack("Q", raw[8:0x10])[0])
        if mnem_addr.getOffset() == 0:
            print(f"[*] Reached null pointer for mnem_addr (index {i})")
            break
        mnem = read_string_at(mnem_addr)
        field_0x10 = struct.unpack("<I", raw[0x10:0x14])[0]
        field_0x14 = struct.unpack("<I", raw[0x14:0x18])[0]
        field_0x18 = struct.unpack("<I", raw[0x18:0x1C])[0]

        all_insn_info_2[field_0] = {
                "opcode": field_0,  # convenience for later use
                "mnemonic": mnem,
                "operand_count": field_0x10,
                "operand1_type": field_0x14,
                "operand2_type": field_0x18,
                }

        i += 1
    return all_insn_info_2


def get_raw_insn_info() -> bytes:
    return read_data_at(INSN_INFO_ADDR, INSN_INFO_LEN)

def get_raw_bytecode() -> bytes:
    return read_data_at(BYTECODE_ADDR, BYTECODE_LEN)

monitor = ConsoleTaskMonitor()
address_factory = currentProgram.getAddressFactory()

print("[*] Dumping insn info structures")
raw_insn_info = get_raw_insn_info()
all_insn_info = dump_insn_info(raw_insn_info)
print(f"[*] Dumped {len(all_insn_info.keys())} entries")
# -1 because the last entry (null entry) is skipped
assert(len(all_insn_info) == INSN_INFO_ENTRY_COUNT - 1)

print("[*] Dumping bytecode")
bytecode = get_raw_bytecode()
assert(len(bytecode) == BYTECODE_LEN)
print(f"[*] Dumped {len(bytecode)} byes")

# Expand bytecode buffer (total size == 0x100)
bytecode_work_buffer = bytearray(bytecode)
padding = bytearray(0x100-0xc8)
bytecode_work_buffer.extend(padding)

dis = Disasm(bytecode_work_buffer, all_insn_info)
 



